
DROP INDEX idx_complaints_created_at;
DROP INDEX idx_complaints_status;
DROP INDEX idx_complaints_complaint_id;
DROP TABLE complaints;
